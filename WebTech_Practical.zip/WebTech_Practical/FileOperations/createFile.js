var fs = require('fs');

txt = "This is demo file";

// Writing the file

fs.writeFile('demo.txt', txt, function(err){
    if(err){throw err;}
    console.log('File is created');
})