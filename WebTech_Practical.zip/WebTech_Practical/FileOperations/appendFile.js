var fs = require('fs');
txt = "This is appended text";
fs.appendFile('demo.txt', txt, function(err){
    if(err){throw err;}
    console.log("File appended successfully")
})