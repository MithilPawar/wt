var fs = require('fs');

fs.readFile('demo.txt', 'utf8', function(err, data){
    if(err){throw err;}
    console.log(data)
})