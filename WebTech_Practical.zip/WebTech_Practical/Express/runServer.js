const { error } = require('console');
var express = require('express');

const app = express();

app.get('/', (req, res)=>{
    res.status(200);
    res.send("Welcome to the url of server");
});

app.listen(7000, (error) =>{
    if(!error){
        console.log("Server running successfully");
    }else{
        console.log("Something went wrong");
    }
});