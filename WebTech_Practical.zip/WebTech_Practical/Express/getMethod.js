var express = require('express');
var app = express();

app.get('/', function(req, res){
    res.sendFile(__dirname + '/regForm.html');
});

app.get('/formSubm', function(req, res){
    const uid = req.query.uid;
    const name = req.query.name;
    const mob = req.query.mob;

    res.send(`<b> <h1>---- User Information----</h1> <br>
    User Id: ${uid} <br> Name: ${name} <br> Mobile: ${mob}`);
    
});

app.listen(7000);