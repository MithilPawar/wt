var express = require('express');
var bodyParser = require('body-parser');

var app = express();

// Use body-parser middleware to parse POST request data
app.use(bodyParser.urlencoded({ extended: true }));

app.get('/', function(req, res) {
    res.sendFile(__dirname + '/regForm.html');
});

app.post('/formSubm', function(req, res) {
    var uid = req.body.uid;
    var name = req.body.name;
    var mob = req.body.mob;

    res.send(`Received data: User Id - ${uid}, Name - ${name}, Mobile - ${mob}`);
});

app.listen(7000, function() {
    console.log('Server is listening on port 7000');
});
