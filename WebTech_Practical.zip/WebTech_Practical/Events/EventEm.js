var events = require('events');

var eventEmmiter = new events.EventEmitter();

var myEventHandler = function(){
    console.log("This event is called......")
}

eventEmmiter.on('ev', myEventHandler);

eventEmmiter.emit('ev');
