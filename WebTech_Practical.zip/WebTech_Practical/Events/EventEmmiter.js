var events = require('events');
var eventEmmiter = new events.EventEmitter();

var myEventHandler = function(){
    console.log("Event called.........");
}

eventEmmiter.on('call', myEventHandler);
eventEmmiter.emit('call');