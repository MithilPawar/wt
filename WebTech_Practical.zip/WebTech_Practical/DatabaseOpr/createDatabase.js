var mysql = require('mysql');

var con = mysql.createConnection({
    host : 'localhost',
    user : 'root',
    password : ''
})

con.connect(function(err){
    if(err){throw err;}
    sql = 'CREATE DATABASE WebPractical';
    con.query(sql, function(err){
        if(err){throw err;}
        console.log("Database created successfully.........")
    })
})