var mysql = require('mysql');

var con = mysql.createConnection({
    host : 'localhost',
    user : 'root',
    password : '',
    database : 'WebPractical'
})

con.connect(function(err){
    if(err){throw err;}
    console.log("connected");

    sql = 'SELECT * FROM student';
    sql1 = 'SELECT * FROM student WHERE rollNo = 60';
    sql2 = 'SELECT * FROM student WHERE percentage > 90';
    sql3 = 'SELECT * FROM student ORDER BY name';
    con.query(sql1, function(err, result){
        if(err){throw err;}

        console.log(result);
    })
})