var mysql = require('mysql');

var con = mysql.createConnection({
    host : 'localhost',
    user : 'root',
    password : '',
    database : 'WebPractical'
})

con.connect(function(err){
    if(err){throw err;}
    console.log("connected");

    sql = 'DROP TABLE student';
    con.query(sql, function(err){
        if(err){throw err;}
        console.log("Table deleted successfully")
    })
})