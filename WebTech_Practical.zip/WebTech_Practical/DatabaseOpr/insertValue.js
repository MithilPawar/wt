var mysql = require("mysql");

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "WebPractical",
});

con.connect(function (err) {
  if (err) {
    throw err;
  }
  console.log("Connected");

//   sql = "INSERT INTO student VALUES(60, 'Mithil', 98.50)";
//   con.query(sql, function (err) {
//     if (err) {
//       throw err;
//     }
//     console.log("Data Inserted Successfully......");
//   });

//   Inserting multiple values
    sql1 = "INSERT INTO student(rollNo, name, percentage) VALUES ?;";
    let val = [
    [1, "Omkar", 87],
    [2, "Bhavesh", 86],
    [3, "Pranay", 91],
    [4, "aafan", 99],
    ];

    con.query(sql1, [val], function(err){
        if(err){throw err;}
        console.log("Values inserted successfully.....");
    })
});
