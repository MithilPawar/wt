exports.myDate = function(){
    return Date();
}