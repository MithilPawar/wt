exports.fact = function(num){
    if(num == 0 || num == 1){
        return 1;
    }else{
        return num * exports.fact(num - 1);
    }
}