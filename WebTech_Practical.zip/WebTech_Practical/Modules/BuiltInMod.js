var http = require("http");
http
  .createServer(function (req, res) {
    res.writeHead(200, "Content-Type:text/plain");
    res.write("This is Built in module");
    res.end();
  })
  .listen(8083);
