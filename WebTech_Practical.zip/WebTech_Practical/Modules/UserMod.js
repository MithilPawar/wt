var http = require('http');
var date = require('./DateMod')
var fac = require('./FactorialMod');
http.createServer(function(req, res){
    res.writeHead(200, 'Content-Type:text/plain');
    res.write("Current Date is : "+ date.myDate());
    res.write("Factorial is: " + fac.fact(5));
    res.end();
}).listen(8083);