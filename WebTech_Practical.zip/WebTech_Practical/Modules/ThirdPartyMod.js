var lo = require('lodash');

var num = [1, 3, 4, 5, 6];

var sum = lo.sum(num);
console.log(sum);

var avg = lo.mean(num);
console.log(avg);