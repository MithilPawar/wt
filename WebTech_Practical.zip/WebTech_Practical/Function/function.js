function square(n){
    return n * n;
}

var num  = 5;
var sqr = square(num);
console.log("Square of the number is: ", sqr);